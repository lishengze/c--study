#include "test.h"
#include "quant_func.h"
#include "fte_func.h"
#include "struct.h"
#include <ctime>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <string>
#include <iostream>

using threadPtr = std::shared_ptr<std::thread>;
/*
* 测试概述
* 1. 基本测试：测试队列的基本功能，包括入队、出队、队列长度、队列是否为空、队列是否已满等。
* 2. 边界测试：测试队列的边界情况，包括队列长度为0、队列长度为最大值、队列已满、队列为空等。
* 3. 并发测试：测试队列在多线程环境下的并发读写。
* 4. 性能测试：测试队列在不同场景下的性能，包括单线程读写、多线程读写、读写效率、队列满载、队列空载等。
* 5. 异常测试：测试队列在异常情况下的行为，包括入队时队列已满、出队时队列为空等。
* 6. 内存泄漏测试：测试队列在使用过程中是否会导致内存泄漏。
* 7. 线程安全测试：测试队列在多线程环境下是否线程安全，包括入队、出队、队列长度、队列是否为空、队列是否已满等。
* 基本参数：
*  数据块大小： 列12个大小， 随机选择写入的大小在 4B ~ 8KB 之间；
*  队列长度： 列10个长度， 随机选择队列长度在1000到10000之间；
*  读写线程数:  列10个线程数， 不使用超线程；
*  共享内存大小: 10-100MB 也就是队列的容量;
*/




int test_quant(MetaData& metaData) {
    TEST_LOG_DETAIL("****************Test Quant Start****************\n");
    if (metaData.iWriteBlockCount == 0 && metaData.iWorkSecs == 0) {
        TEST_LOG_ERROR("Test MPMC failed, both write block count and write secs is 0\n");
    }

    // 初始化共享内存相关;
    unsigned long  ulQueSize = (metaData.iMemMBSize<<20);  // 转换为字节(MB -> B)    

    // 表示进行数量读写的并发量的压力测试, 給队列申请足够的写入空间;
    if (metaData.iWorkSecs == 0) {
        double dBlockSize = 8;
        if (metaData.iFixedBlock == (int)(BlockType::FixedStruct)) {
            dBlockSize = sizeof(DataBlockFixed);
        }
        ulQueSize = metaData.iWriteBlockCount * dBlockSize * 1.2;
    }

    // 计算所需内存大小,取 2 的幂次方;
    unsigned long  ulMemorySize = que_proc_buf::need_buf_size(ulQueSize);

    TEST_LOG_DETAIL("Memory Size=" + std::to_string(ulMemorySize) + "B, Que Size=" + std::to_string(ulQueSize) + " B");

    ulMemorySize += sizeof(que_proc_info);  // 加上队列元数据大小
    
    
    // void *pSharedMem = NULL;    
    // int ret = comm_utils::map_shm(pSharedMem,"test_proc_que",ulMemorySize,0);
    // TEST_LOG_DETAIL("Create shared memory mmap que,ret=" + std::to_string(ret));
    // if(ret < 0) {
    //     return ret;  // 共享内存创建失败
    // }

    int ret = 1;
    void * pSharedMem = malloc(ulMemorySize);
    if (NULL == pSharedMem) {
        return -1;
    }

    // 初始化队列
    que_proc_info* pQueProcInfo = (que_proc_info *)pSharedMem;
    que_proc_buf queProBuf;
    queProBuf.init_shm(pQueProcInfo,((char *)pSharedMem) + sizeof(que_proc_info), ulQueSize, ret, 1024, 0);
    queProBuf.start(QUE_RECOVE_TYPE_RESTART);  // 启动队列，设置重启恢复模式

    std::vector<threadPtr> vecWriteTheads;
    vecWriteTheads.reserve(metaData.iWriteThreadCount);

    std::vector<threadPtr> vecReadTheads;
    vecReadTheads.reserve(metaData.iReadThreadCount);   
    
    std::vector<int64> vecReadPos;
    vecReadPos.reserve(metaData.iReadThreadCount);

    std::vector<DataBlockPtr> vecPushBlocks;
    vecPushBlocks.reserve(metaData.iWriteBlockCount);
    std::vector<DataBlockPtr> vecPopBlocks;
    vecPopBlocks.reserve(metaData.iWriteBlockCount);

    std::vector<unsigned long long> vecCostTime;
    vecCostTime.reserve(metaData.iWriteBlockCount);

    std::vector<unsigned long long> vecStartTime;
    vecStartTime.reserve(metaData.iWriteThreadCount + metaData.iReadThreadCount);

    std::vector<unsigned long long> vecEndTime;
    if (metaData.iReadType > 0) {
        vecEndTime.reserve(metaData.iWriteThreadCount + metaData.iReadThreadCount + 1);   // 多一个写入提交线程;
    } else {
        vecEndTime.reserve(metaData.iWriteThreadCount + metaData.iReadThreadCount);  
    }
      

    std::vector<TestOutput> vecWriteTestOutput;
    vecWriteTestOutput.reserve(metaData.iWriteThreadCount);
    for (int i = 0; i <metaData.iWriteThreadCount; ++i ) {
        vecWriteTestOutput.push_back(metaData.iWriteBlockCount / metaData.iWriteThreadCount);
    }

    std::vector<TestOutput> vecReadTestOutput;
    vecReadTestOutput.reserve(metaData.iReadThreadCount);
    for (int i = 0; i <metaData.iReadThreadCount; ++i ) {
        vecReadTestOutput.push_back(metaData.iWriteBlockCount / metaData.iReadThreadCount);
    }      

    ProcessStatus eProcStatus = ProcessStatus::Initing;        

    std::atomic<unsigned long long> ulAtoReadCount(0);  // 总共读取的数量;
    std::atomic<unsigned long long> ulAtoWriteCount(0);  // 总共写入的数量;

    std::mutex LogMutex;

    int iThreadIndex = 0;

    // 不是只测写入;
    if (metaData.iTestType != (int)TestType::Write) {
        /* 开启读线程 */
        for (int i = 0; i < metaData.iReadThreadCount; i++) {
            if(metaData.iReadType == 0){
                // 创建普通读取线程
                int iCurWorkCPU = metaData.vecReadCpuList[i%metaData.vecReadCpuList.size()];
                threadPtr pThread = std::make_shared<std::thread>(read_thread_func_quant_simple, 
                                                        std::ref(eProcStatus), std::ref(queProBuf),  
                                                        std::ref(vecPopBlocks), std::ref(vecCostTime), std::ref(ulAtoReadCount),
                                                        std::ref(vecStartTime[iThreadIndex]),std::ref(vecEndTime[iThreadIndex]),
                                                        std::ref(vecReadTestOutput[i]), iCurWorkCPU, std::ref(LogMutex), metaData);
                if (nullptr == pThread) {
                    printf("create read simple thread failed\n");
                    continue;
                }
                iThreadIndex++;
                vecReadTheads.push_back(pThread);
            }
            else{
                // 创建位置模式读取线程
                int iCurWorkCPU = metaData.vecReadCpuList[i%metaData.vecReadCpuList.size()];
                threadPtr pThread = std::make_shared<std::thread>(read_thread_func_quant_pos, 
                                                        std::ref(eProcStatus),  std::ref(vecReadPos[i]), std::ref(queProBuf),  
                                                        std::ref(vecPopBlocks), std::ref(vecCostTime), std::ref(ulAtoReadCount), 
                                                        std::ref(vecStartTime[iThreadIndex]),std::ref(vecEndTime[iThreadIndex]), 
                                                        std::ref(vecReadTestOutput[i]), iCurWorkCPU, std::ref(LogMutex), metaData);
                if (nullptr == pThread) {
                    printf("create read pos thread failed\n");
                    continue;
                }
                iThreadIndex++;
                vecReadTheads.push_back(pThread);
            }
        }

        if (metaData.iReadType > 0) {
            // 创建提交线程
            // int iCurWorkCPU = metaData.vecReadCpuList[metaData.vecReadCpuList.size()-1];
            threadPtr pThread = std::make_shared<std::thread>(read_thread_func_quant_cmt, 
                                                                std::ref(eProcStatus), std::ref(queProBuf),  
                                                                std::ref(vecReadPos), std::ref(vecPopBlocks),
                                                                std::ref(vecEndTime[iThreadIndex]),
                                                                std::ref(LogMutex), metaData);    
            if (nullptr == pThread) {
                printf("create commit thread failed\n");
            }
            iThreadIndex++;
            vecReadTheads.push_back(pThread);
        }
    }


        /* 开启写线程 */
        for (int i = 0; i < metaData.iWriteThreadCount; i++) {
            int iCurWorkCPU = metaData.vecWriteCpuList[i%metaData.vecWriteCpuList.size()];
            threadPtr pThread = std::make_shared<std::thread>(write_thread_func_quant, 
                                                                std::ref(eProcStatus), std::ref(queProBuf),  
                                                                std::ref(vecPushBlocks), std::ref(ulAtoWriteCount), 
                                                                std::ref(vecStartTime[iThreadIndex]), std::ref(vecEndTime[iThreadIndex]),
                                                                std::ref(vecWriteTestOutput[i]), iCurWorkCPU, 
                                                                std::ref(LogMutex), metaData);
            if (nullptr == pThread) {
                printf("create write thread failed\n");
                continue;
            }
            iThreadIndex++;
            vecWriteTheads.push_back(pThread);
        }


    eProcStatus = ProcessStatus::Running;

    // 如果未设置写入的块数，则等待指定的时间
    if (metaData.iWorkSecs > 0) {
        TEST_LOG_DETAIL(std::string("Start Work ") + std::to_string(metaData.iWorkSecs));
        std::this_thread::sleep_for(std::chrono::seconds(metaData.iWorkSecs));
        eProcStatus = ProcessStatus::Stop;
        TEST_LOG_DETAIL(std::string("Word END"));
    }

    for (auto pThread : vecWriteTheads) {
        if (pThread->joinable()) {
            pThread->join();
        }
    }

    for (auto pThread : vecReadTheads) {
        if (pThread->joinable()) {
            pThread->join();
        }
    }

    for (auto& tmp:vecEndTime) {
        TEST_LOG_DETAIL(NanoToMicroString(tmp)+ "\n");
    }

    std::sort(vecStartTime.begin(), vecStartTime.end());
    std::sort(vecEndTime.begin(), vecEndTime.end());

    for (auto& tmp:vecEndTime) {
        TEST_LOG_DETAIL(NanoToMicroString(tmp)+ "\n");
    }

    unsigned long long ulEndNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
    unsigned long long costNanosecs = ulEndNanosecs - vecStartTime[0];

    LOG_RST(string("\n***************** Test Result Quant Queue ****************\n") + metaData.str() );

    std::string strTestoutputStr = "";
    if (metaData.iTestType != (int)TestType::Read) {        
        strTestoutputStr +=  GetAnaTestOutputRst (vecWriteTestOutput,1);
    }
    if (metaData.iTestType != (int)TestType::Write) {
        strTestoutputStr +=  GetAnaTestOutputRst (vecReadTestOutput, 2);
    }
    LOG_RST(strTestoutputStr);

    if (metaData.iTestType == (int)TestType::Both) {
        std::string strAnaStr = GetAnaRst(vecCostTime,metaData, costNanosecs, "Quant_Queue");
        LOG_RST(strAnaStr);    
    }


    TEST_LOG_DETAIL("[END] "+ NanoToMicroString(vecStartTime[0]) +" Quant Thread All end "+ NanoToMicroString(ulEndNanosecs) +"\n");    


    // 释放共享内存
    // comm_utils::close_shm(pSharedMem,"test_proc_que",ulMemorySize);

    if (NULL != pSharedMem) {
        free(pSharedMem);
    }

    return 0;
}

int test_mpmc(MetaData& metaData) {
    TEST_LOG_DETAIL("****************Test MPMC Start****************\n");

    if (metaData.iWriteBlockCount == 0 && metaData.iWorkSecs == 0) {
        TEST_LOG_ERROR("Test MPMC failed, both write block count and write secs is 0\n");
    }

    std::vector<threadPtr> vecWriteTheads;
    vecWriteTheads.reserve(metaData.iWriteThreadCount);

    std::vector<threadPtr> vecReadTheads;
    vecReadTheads.reserve(metaData.iReadThreadCount);   
    
    std::vector<unsigned long long> vecCostTime;
    vecCostTime.reserve(metaData.iWriteBlockCount);

    std::vector<unsigned long long> vecStartTime;
    vecStartTime.reserve(metaData.iWriteThreadCount + metaData.iReadThreadCount);

    std::vector<unsigned long long> vecEndTime;
    vecEndTime.reserve(metaData.iWriteThreadCount + metaData.iReadThreadCount);   

    std::vector<TestOutput> vecWriteTestOutput;
    vecWriteTestOutput.reserve(metaData.iWriteThreadCount);
    for (int i = 0; i <metaData.iWriteThreadCount; ++i ) {
        vecWriteTestOutput.push_back(metaData.iWriteBlockCount / metaData.iWriteThreadCount);
    }

    std::vector<TestOutput> vecReadTestOutput;
    vecReadTestOutput.reserve(metaData.iReadThreadCount);
    for (int i = 0; i <metaData.iReadThreadCount; ++i ) {
        vecReadTestOutput.push_back(metaData.iWriteBlockCount / metaData.iReadThreadCount);
    }


    int iThreadIndex = 0;

    ProcessStatus eProcStatus = ProcessStatus::Initing;          
    std::atomic<unsigned long long> ulAtoReadCount(0);  // 原子计数器
    std::atomic<unsigned long long> ulAtoWriteCount(0);  // 原子计数器
    std::mutex mtx;

    unsigned int uiQueueSize = 4000;  // 默认的队列长度

    // 表示进行数量读写的并发量的压力测试, 給队列申请足够的写入空间;
    if (metaData.iWorkSecs == 0) {
        double dBlockSize = 8;
        if (metaData.iFixedBlock == (int)(BlockType::FixedPOD)) {
            dBlockSize = sizeof(DataBlockFixed);
        }
        uiQueueSize = metaData.iWriteBlockCount * 1.2;
    }

    TEST_LOG_DETAIL("MPMC QUEUE SIZE: " + std::to_string(uiQueueSize));

    

    tech::mpmc_queue<DataBlockFixed> dataBlockFixedQueue;
    tech::mpmc_queue<unsigned long long> ulQueue;

    std::mutex LogMutex;

    TestOutput testOutput(metaData.iWriteBlockCount);
    TestOutput writeTestOutput(metaData.iWriteBlockCount/metaData.iWriteThreadCount);
    TestOutput readTestOutput(metaData.iWriteBlockCount/metaData.iReadThreadCount);

    // BindCpuID(10);

    unsigned long long ulStartNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();


    if (metaData.iFixedBlock == 1) {
        
        dataBlockFixedQueue.create(uiQueueSize);

        // eProcStatus = ProcessStatus::Running;

        // 不是只测写入
        if (metaData.iTestType != (int)TestType::Write) {
            /* 开启读线程 */
            for (int i = 0; i < metaData.iReadThreadCount; i++) {

                // vecReadTestOutput[i] = TestOutput(metaData.iWriteBlockCount / metaData.iReadThreadCount);
                
                int iCurWorkCPU = metaData.vecReadCpuList[i%metaData.vecReadCpuList.size()];

                threadPtr pThread = std::make_shared<std::thread>(read_thread_func_mpmc<DataBlockFixed>, 
                                                                    std::ref(eProcStatus), std::ref(dataBlockFixedQueue),  
                                                                    std::ref(mtx), std::ref(ulAtoReadCount), std::ref(vecCostTime),  
                                                                    std::ref(vecStartTime[iThreadIndex]),
                                                                    std::ref(vecEndTime[iThreadIndex]), 
                                                                    std::ref(vecReadTestOutput[i]),iCurWorkCPU, 
                                                                    std::ref(LogMutex), std::ref(metaData));
                iThreadIndex++;
                if (nullptr == pThread) {
                    TEST_LOG_DETAIL("create read simple thread failed\n");
                    continue;
                }
                vecReadTheads.push_back(pThread);
            }

        }


            /* 开启写线程 */
            for (int i = 0; i < metaData.iWriteThreadCount; i++) {

                int iCurWorkCPU = metaData.vecWriteCpuList[i%metaData.vecWriteCpuList.size()];

                // vecWriteTestOutput[i] = TestOutput(metaData.iWriteBlockCount / metaData.iWriteThreadCount);

                threadPtr pThread = std::make_shared<std::thread>(write_thread_func_mpmc<DataBlockFixed>, 
                                                                    std::ref(eProcStatus), std::ref(dataBlockFixedQueue),  
                                                                    std::ref(mtx), std::ref(ulAtoWriteCount), 
                                                                    std::ref(vecStartTime[iThreadIndex]), 
                                                                    std::ref(vecEndTime[iThreadIndex]), 
                                                                    std::ref(vecWriteTestOutput[i]), iCurWorkCPU, 
                                                                    std::ref(LogMutex),  std::ref(metaData));
                if (nullptr == pThread) {
                    TEST_LOG_DETAIL("create write thread failed\n");
                    continue;
                }
                iThreadIndex++;
                vecWriteTheads.push_back(pThread);
            }       
        
 
    }
    else if (metaData.iFixedBlock == 2) {
        ulQueue.create(uiQueueSize);

        // eProcStatus = ProcessStatus::Running;

        // 不是只测写入
        if (metaData.iTestType != (int)TestType::Write) {
            /* 开启读线程 */
            for (int i = 0; i < metaData.iReadThreadCount; i++) {

                int iCurWorkCPU = metaData.vecReadCpuList[i%metaData.vecReadCpuList.size()];

                threadPtr pThread = std::make_shared<std::thread>(read_thread_func_mpmc<unsigned long long>, 
                                                                    std::ref(eProcStatus), std::ref(ulQueue),  
                                                                    std::ref(mtx), std::ref(ulAtoReadCount), std::ref(vecCostTime),  
                                                                    std::ref(vecStartTime[iThreadIndex]), std::ref(vecEndTime[iThreadIndex]), 
                                                                    std::ref(vecReadTestOutput[i]),iCurWorkCPU, 
                                                                    std::ref(LogMutex),  std::ref(metaData));
                if (nullptr == pThread) {
                    TEST_LOG_DETAIL("create read simple thread failed\n");
                    continue;
                }
                iThreadIndex++;
                vecReadTheads.push_back(pThread);
            }
        }

        


        /* 开启写线程 */
        for (int i = 0; i < metaData.iWriteThreadCount; i++) {

            int iCurWorkCPU = metaData.vecWriteCpuList[i%metaData.vecWriteCpuList.size()];

            threadPtr pThread = std::make_shared<std::thread>(write_thread_func_mpmc<unsigned long long>, 
                                                                std::ref(eProcStatus), std::ref(ulQueue),  
                                                                std::ref(mtx), std::ref(ulAtoWriteCount), 
                                                                std::ref(vecStartTime[iThreadIndex]), std::ref(vecEndTime[iThreadIndex]), 
                                                                std::ref(vecWriteTestOutput[i]), iCurWorkCPU, 
                                                                std::ref(LogMutex),  std::ref(metaData));
            if (nullptr == pThread) {
                TEST_LOG_DETAIL("create write thread failed\n");
                continue;
            }
            iThreadIndex++;
            vecWriteTheads.push_back(pThread);
        }          
    }

    
    eProcStatus = ProcessStatus::Running;


    // 如果未设置写入的块数，则等待指定的时间
    if (metaData.iWorkSecs > 0) {
        TEST_LOG_DETAIL(std::string("Start Work ") + std::to_string(metaData.iWorkSecs));
        std::this_thread::sleep_for(std::chrono::seconds(metaData.iWorkSecs));
        eProcStatus = ProcessStatus::Stop;

        TEST_LOG_DETAIL(std::string("Work ALL END, eProcStatus: ") + std::to_string((int)(eProcStatus)));
    }    


    for (auto pThread : vecReadTheads) {
            if (pThread->joinable()) {
                pThread->join();
            }
    }    
        
    for (auto pThread : vecWriteTheads) {
        if (pThread->joinable()) {
            pThread->join();
        }
    }

    std::sort(vecStartTime.begin(), vecStartTime.end());
    std::sort(vecEndTime.begin(), vecEndTime.end());

    unsigned long long ulEndNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
    unsigned long long costNanosecs = ulEndNanosecs - ulStartNanosecs;


    LOG_RST(string("\n***************** Test Result MPMC Queue ****************\n") + metaData.str() );

    std::string strTestoutputStr = "";
    if (metaData.iTestType != (int)TestType::Read) {
        strTestoutputStr +=  GetAnaTestOutputRst (vecWriteTestOutput,1);
    }
    if (metaData.iTestType != (int)TestType::Write) {
        strTestoutputStr +=  GetAnaTestOutputRst (vecReadTestOutput, 2);
    }
    LOG_RST(strTestoutputStr);

    if (metaData.iTestType == (int)TestType::Both) {
        std::string strAnaStr = GetAnaRst(vecCostTime,metaData, costNanosecs, "MPMC_Queue");
        LOG_RST(strAnaStr);    
    }




    // TEST_LOG_DETAIL(strAnaStr);

    TEST_LOG_DETAIL("[END] "+ NanoToMicroString(vecStartTime[0]) +" MPMC Thread All end "+ NanoToMicroString(ulEndNanosecs) +"\n");    

    return 1;
}

void TestMain() {

    std::string sConfigFileName = GetWorkDir() + "config.json";
    // std::cout << "sConfigFileName: " << sConfigFileName << std::endl;
    njson fileJson;
    Error error;
    if ((error = GetJsonFromFile(fileJson, sConfigFileName)).IsFailed()) {
        TEST_LOG_FAIL("GetJsonFromFile failed, error: " + error.Str() + "\n");
        return;
    }

    MetaData metaData;
    string sErrMsg;    
    njson jsCaseList = fileJson["CaseList"];
    if (jsCaseList.is_array()) {
        for (njson::iterator it = jsCaseList.begin(); it != jsCaseList.end(); ++it) {           
            njson jsAtom = *it;
            if (!metaData.InitFromJson(jsAtom, sErrMsg)) {
                TEST_LOG_ERROR( "InitFromJson failed, error: " + sErrMsg + "\n");
                continue;
            }
            TEST_LOG_DETAIL("Test Meta Info:\n" + metaData.str());

            if (metaData.iQueueType == 0) {
                test_mpmc(metaData);
                test_quant(metaData);
            }
            else if (metaData.iQueueType == 1) {
                test_quant(metaData);
            } else if (metaData.iQueueType == 2) {
                test_mpmc(metaData);
            }
        }
    } else {
        TEST_LOG_ERROR("Test CaseList is not array\n");
    }
}