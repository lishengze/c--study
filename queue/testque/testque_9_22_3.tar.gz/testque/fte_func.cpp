
#include <chrono>
#include <thread>
#include <vector>
#include <iostream>

#include "fte_func.h"
#include "mpmc_queue.h"
#include "test_log.h"

using namespace std;


/// @brief 判断是否写入结束: 写入的数量, 写入的时间;
/// @param ulAtoWriteCount 写入的块数
/// @param metaData 元数据
/// @param ulStartWriteTimeNanosecs 写入开始时间
/// @return true 写入结束
/// @return false 写入未结束
bool IsFteWriteEnd(ProcessStatus& eProcStatus, std::atomic<unsigned long long>& ulAtoWriteCount, MetaData& metaData, int& iCurCount) {
    if (ProcessStatus::Running != eProcStatus) return true;

    if (metaData.iWorkSecs == 0 && metaData.iWriteBlockCount > 0 && iCurCount >= metaData.iWriteBlockCount/metaData.iWriteThreadCount ) return true;

    // std::cout << "eProcStatus: " << (int)eProcStatus << ", ulAtoWriteCount: " << ulAtoWriteCount << ", iWorkSecs: " << metaData.iWorkSecs << ", iWriteBlockCount: " << metaData.iWriteBlockCount << std::endl;

    return false;
}

/// @brief 判断是否写入结束: 写入的数量, 写入的时间;
/// @param ulAtoWriteCount 写入的块数
/// @param metaData 元数据
/// @param ulStartWriteTimeNanosecs 写入开始时间
/// @return true 写入结束
/// @return false 写入未结束
bool IsFteReadEnd(ProcessStatus& eProcStatus, std::atomic<unsigned long long>& ulAtoReadCount, MetaData& metaData) {
    if (ProcessStatus::Running != eProcStatus && ProcessStatus::WriteEnd != eProcStatus) return true;

    if (ulAtoReadCount >= metaData.iWriteBlockCount && metaData.iWriteBlockCount > 0 && metaData.iWorkSecs == 0) return true;

    // std::cout << "eProcStatus: " << (int)eProcStatus << ", ulAtoReadCount: " << ulAtoReadCount << ", iWorkSecs: " << metaData.iWorkSecs << ", iWriteBlockCount: " << metaData.iWriteBlockCount << std::endl;

    return false;
}


template <>
void write_thread_func_mpmc<DataBlockFixed>(ProcessStatus& eProcStatus, tech::mpmc_queue<DataBlockFixed>& queue, 
                                            std::mutex& mtx, std::atomic<unsigned long long>& ulAtoWriteCount,
                                            unsigned long long& ulStartNanosecs, unsigned long long& ulEndNanosecs,
                                            TestOutput& testOutput, int iCpuID, 
                                            std::mutex& LogMutex, MetaData& metaData) {

    TEST_LOG_DETAIL_THREADS("[START] MPMC Write Thread DataBlockFixed Initing ***********************\n", LogMutex);
    BindCpuID(iCpuID, metaData.iNumaNode, "MPMC Write ");
    while(eProcStatus == ProcessStatus::Initing ) {
        // std::this_thread::sleep_for(std::chrono::microseconds(1));
    }
    TEST_LOG_DETAIL_THREADS("[START] MPMC Write Thread DataBlockFixed Working ***********************\n", LogMutex);

    ulStartNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    testOutput.ulWriteStartTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    int iCurCount = 0;
    unsigned long long ulPushedFailedCount = 0;
    while(!IsFteWriteEnd(eProcStatus, ulAtoWriteCount, metaData, iCurCount)) {
            DataBlockFixed dataBlock;
            dataBlock.size_ = sizeof(DataBlockFixed);
            dataBlock.push_time_  = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

            unsigned long long ulCurTimeNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
            testOutput.vecWriteBeforePushTimeList.push_back(ulCurTimeNanosecs);

            queue.push(dataBlock);
            ulAtoWriteCount++;
            iCurCount++;

            ulCurTimeNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
            testOutput.vecWriteAfterPushTimeList.push_back(ulCurTimeNanosecs); //core;            

            // if (!queue.trypush(dataBlock) ) {
            //     ulPushedFailedCount++;
            // } else {
            //     ulAtoWriteCount++;
            //     iCurCount++;
            // }

            if (metaData.iSleepTimeUs > 0) {
                std::this_thread::sleep_for(std::chrono::microseconds(metaData.iSleepTimeUs));
            }
    }

    std::lock_guard<std::mutex> lock(mtx);
    ulEndNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    testOutput.ulWriteEndTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    if (metaData.iTestType == (int)(TestType::Read)) {
        eProcStatus = ProcessStatus::WriteEnd;
    } 

    // TEST_LOG_DEBUG_THREADS("TryPush Failed Counts: " + std::to_string(ulPushedFailedCount), LogMutex)

    TEST_LOG_DETAIL_THREADS("[END] MPMC Write  ulAtoWriteCount: "
                    + std::to_string(ulAtoWriteCount) 
                    +", eProcStatus: "+std::to_string((int)eProcStatus)
                    + ", endTime:" + NanoToMicroString(ulEndNanosecs) 
                    + " ***********************\n", LogMutex);
}


template <>
void read_thread_func_mpmc<DataBlockFixed>(ProcessStatus& eProcStatus, tech::mpmc_queue<DataBlockFixed>& queue, 
                                            std::mutex& mtx,  std::atomic<unsigned long long>& ulAtoReadCount, 
                                            std::vector<unsigned long long>& vecCostTime, 
                                            unsigned long long& ulStartNanosecs, unsigned long long& ulEndNanosecs,
                                            TestOutput& testOutput, int iCpuID, 
                                            std::mutex& LogMutex,  MetaData& metaData) {

    TEST_LOG_DETAIL_THREADS("[START] MPMC  Initing ***********************\n", LogMutex);
    BindCpuID(iCpuID, metaData.iNumaNode,"MPMC Read ");

    while(eProcStatus == ProcessStatus::Initing 
        || (metaData.iTestType == (int)(TestType::Read) && eProcStatus != ProcessStatus::WriteEnd)) {
        // std::this_thread::sleep_for(std::chrono::microseconds(1));
    }

    testOutput.ulReadStartTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    TEST_LOG_DETAIL_THREADS("[START] MPMC  Working "+ NanoToMicroString(testOutput.ulWriteStartTime ) +" ***********************\n", LogMutex);

    ulStartNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    DataBlockFixed dataBlock;
    unsigned long long ulPopFailCount = 0;
    while(!IsFteReadEnd(eProcStatus, ulAtoReadCount, metaData) ) {
        
        
        // queue.pop(dataBlock);
        unsigned long long ulBeforePopTimes = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
        // vecCostTime.push_back(ulCurTimeNanosecs - dataBlock.push_time_);
        // ulAtoReadCount++;

        if (queue.trypop(dataBlock)) {
            testOutput.vecReadBeforePopTimeList.push_back(ulBeforePopTimes);

            unsigned long long ulCurTimeNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
            vecCostTime.push_back(ulCurTimeNanosecs - dataBlock.push_time_);
            ulAtoReadCount++;        

            testOutput.vecReadAfterPopTimeList.push_back(ulCurTimeNanosecs);    

            if (1 == metaData.iCheckDetailValue) {
                if (dataBlock.data_[dataBlock.array_size_ - 1] != (dataBlock.array_size_ - 1) % 128) {
                    TEST_LOG_ERROR_THREADS (" Read Data Error: dataBlock.data_[" + std::to_string(dataBlock.array_size_ - 1) + "] = "
                                            + std::to_string(int(dataBlock.data_[dataBlock.array_size_ - 1]))+ ", endTime:" + NanoToMicroString(ulEndNanosecs)  + "\n",  LogMutex);
                }
            }
        } else {
            ++ulPopFailCount;
        }
    }
    // ulEndNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
    // TEST_LOG_DEBUG_THREADS("TryPop Failed Counts: " + std::to_string(ulPopFailCount), LogMutex);

    testOutput.ulReadEndTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    TEST_LOG_DETAIL_THREADS("[END] MPMC Read  ulAtoReadCount: "
                    + std::to_string(ulAtoReadCount)
                    +", eProcStatus: "+std::to_string((int)eProcStatus)
                    + ", endTime:" + NanoToMicroString(testOutput.ulReadEndTime) 
                    +" **********************\n", LogMutex);
}

template <>
void write_thread_func_mpmc<unsigned long long>(ProcessStatus& eProcStatus, tech::mpmc_queue<unsigned long long>& queue, 
                                                std::mutex& mtx,  std::atomic<unsigned long long>& ulAtoWriteCount, 
                                                unsigned long long& ulStartNanosecs, unsigned long long& ulEndNanosecs, 
                                                TestOutput& testOutput,int iCpuID,  
                                                std::mutex& LogMutex, MetaData& metaData) {

    TEST_LOG_DEBUG_THREADS("[START] MPMC Write  Initing ***********************\n", LogMutex);
    BindCpuID(iCpuID, metaData.iNumaNode, "MPMC Write ");
    int iCurCount = 0;
    unsigned long long ulPushedFailedCount = 0;

    // vector<int> vecPushIndex;
    // vector<unsigned long long> vecPushTime;

    // vecPushIndex.reserve(metaData.iWriteBlockCount);
    // vecPushTime.reserve(metaData.iWriteBlockCount);


    while(eProcStatus == ProcessStatus::Initing ) {
        // std::this_thread::sleep_for(std::chrono::microseconds(1));
    }


    // std::this_thread::sleep_for(std::chrono::microseconds(100000));

    ulStartNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    testOutput.ulWriteStartTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();


    TEST_LOG_DEBUG_THREADS("[START] MPMC Write  Working Time: "+ NanoToNanoString(testOutput.ulWriteStartTime) +"  ***********************\n", LogMutex);

    do {
        unsigned long long ulCurTimeNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
        testOutput.vecWriteBeforePushTimeList.push_back(ulCurTimeNanosecs);

        int index = queue.push(ulCurTimeNanosecs);
        ulAtoWriteCount++;
        iCurCount++;

        ulCurTimeNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

        // testOutput.vecWriteSlotList.push_back(index);
        testOutput.vecWriteAfterPushTimeList.push_back(ulCurTimeNanosecs); //core;

        // if (!queue.trypush(ulCurTimeNanosecs) ) {
        //     ulPushedFailedCount++;
        // } else {
        //     ulAtoWriteCount++;
        //     iCurCount++;
        // }

        if (metaData.iSleepTimeUs > 0) {
            std::this_thread::sleep_for(std::chrono::microseconds(metaData.iSleepTimeUs));
        }
    }  while(!IsFteWriteEnd(eProcStatus, ulAtoWriteCount, metaData, iCurCount));

    std::lock_guard<std::mutex> lock(mtx);
    ulEndNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    testOutput.ulWriteEndTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();


    // // TEST_LOG_DEBUG_THREADS("TryPush Failed Counts: " + std::to_string(ulPushedFailedCount), LogMutex);

    if (metaData.iTestType == (int)(TestType::Read)) {
        eProcStatus = ProcessStatus::WriteEnd;
    } 


    TEST_LOG_DETAIL_THREADS("[END] MPMC Write  End ulAtoWriteCount: "
                    + std::to_string(ulAtoWriteCount)
                    +", eProcStatus: "+std::to_string((int)eProcStatus) 
                    + ", dataCount: " + std::to_string(testOutput.vecWriteBeforePushTimeList.size())
                    + ", endTime:" + NanoToMicroString(testOutput.ulWriteEndTime ) 
                    +" ***********************\n", LogMutex);
}


template <>
void read_thread_func_mpmc<unsigned long long>(ProcessStatus& eProcStatus, tech::mpmc_queue<unsigned long long>& queue, 
                                                std::mutex& mtx,  std::atomic<unsigned long long>& ulAtoReadCount, 
                                                std::vector<unsigned long long>& vecCostTime,
                                                unsigned long long& ulStartNanosecs,  unsigned long long& ulEndNanosecs,
                                                TestOutput& testOutput,int iCpuID, 
                                                std::mutex& LogMutex, MetaData& metaData) {

    TEST_LOG_DEBUG_THREADS("[START] MPMC Read  Initing ***********************\n", LogMutex);
    BindCpuID(iCpuID, metaData.iNumaNode,"MPMC Read ");

    unsigned long long ulPopFailCount = 0;


    while(eProcStatus == ProcessStatus::Initing 
        || (metaData.iTestType == (int)(TestType::Read) && eProcStatus != ProcessStatus::WriteEnd)) {
        // std::this_thread::sleep_for(std::chrono::microseconds(1));
    }

    ulStartNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    testOutput.ulReadStartTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();


    TEST_LOG_DEBUG_THREADS("[START] MPMC Read  Working  Time: "+ NanoToNanoString(testOutput.ulReadStartTime) 
                +"***********************\n", LogMutex);

    do {

        unsigned long long ulPushTimeNanosecs = 0;
                unsigned long long ulCurTimeNanosecs;

        unsigned long long ulBeforePopTimes = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
        

        if (queue.trypop(ulPushTimeNanosecs)) {
            testOutput.vecReadBeforePopTimeList.push_back(ulBeforePopTimes);
            ulCurTimeNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
            vecCostTime.push_back(ulCurTimeNanosecs - ulPushTimeNanosecs);
            ulAtoReadCount++;                  
            testOutput.vecReadAfterPopTimeList.push_back(ulCurTimeNanosecs); 
        } else {
            ulPopFailCount++;
        }

        // int index = queue.pop(ulPushTimeNanosecs);
        // unsigned long long ulCurTimeNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
        // vecCostTime.push_back(ulCurTimeNanosecs - ulPushTimeNanosecs);
        // ulAtoReadCount++;   

        // testOutput.vecReadSlotList.push_back(index);
        // testOutput.vecReadAfterPopTimeList.push_back(ulCurTimeNanosecs);
        // vecPopCostTimes.push_back(ulCurTimeNanosecs - ulBeforePopTimes);

        // queue.pop(ulPushTimeNanosecs);
        // vecCostTime.push_back(ulCurTimeNanosecs - ulPushTimeNanosecs);
        // ulAtoReadCount++;        

    }while(!IsFteReadEnd(eProcStatus, ulAtoReadCount, metaData));

    ulEndNanosecs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();

    testOutput.ulReadEndTime = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();


    // TEST_LOG_DEBUG_THREADS("TryPop Failed Counts: " + std::to_string(ulPopFailCount), LogMutex);


    TEST_LOG_DETAIL_THREADS("[END] MPMC Read Thread  ulAtoReadCount: "
                    + std::to_string(ulAtoReadCount)
                    +", eProcStatus: "+std::to_string((int)eProcStatus)
                    + ", dataCount: "+std::to_string(testOutput.vecReadAfterPopTimeList.size())
                    + ", endTime:" + NanoToMicroString(testOutput.ulReadEndTime) 
                    +" **********************\n", LogMutex);
}
