#include <iostream>
#include <unistd.h>

#include "lib_src/strategy_message_manager.h"
#include "lib_src/external_message.h"


namespace share_common 
{
void StragegyOnEvent(int iErrCode, const char* pErrDesc)
{
	//UTEϵͳ�쳣����
}

void StragegyOnMessage(int iMsgID, const char* pMsgBuf, const int iMsgLen)
{
	//�������е�½�ر�����
    if (kPktLoginAns == iMsgID) {
        LogOnAns* ans = (LogOnAns*)pMsgBuf;
        if (0 == ans->error_code) {
            std::cout << "��¼�ɹ�" << std::endl;
        } else {
            std::cout << "��¼ʧ�ܣ������룺" << ans->error_code << std::endl;
        }
    }
    else if(kPktOrderAns == iMsgID)
    {
        TradeOrderER* ans  = (TradeOrderER*)pMsgBuf;
        //����ί�лر�
    }
    else if(kPktOrderMatch == iMsgID)
    {
        TradeOrderER* ans = (TradeOrderER*)pMsgBuf;
        //�����ɽ��ر�
    }

}

// �������е�¼��������
void DoLoginReq(StrategyMessageManager& stragegyMsgManager) {
    LogOnReq req = {0};
    req.heart_bt_int = 3;
    req.trade_order_user.agw_seq_id = 10001;
    strcpy(req.password, "XXXXXX");
    strcpy(req.trade_order_user.fund_account_id, "XXXXXX");
    strcpy(req.trade_order_user.branch_id, "XXXXXX");
    strcpy(req.trade_order_user.account_id, "XXXXXX");
    strcpy(req.trade_order_user.cust_id, "XXXXXX");
    req.trade_order_user.client_seq_id = 1;

    stragegyMsgManager.SendMsg(kPktLoginReq, (char*)&req, sizeof(req));
}

void DoTradeOrderReq(StrategyMessageManager& stragegyMsgManager) {
    TradeOrderReq req = {0};
    strcpy(req.trade_order_user.fund_account_id, "XXXXXX");
    strcpy(req.trade_order_user.branch_id, "XXXXXX");
    strcpy(req.trade_order_user.account_id, "XXXXXX");
    strcpy(req.trade_order_user.cust_id, "XXXXXX");
    req.trade_order_user.client_seq_id = 10001;
    req.trade_order_info.order_qty = 800;
    req.trade_order_info.side = kBuy;
    req.trade_order_info.order_type = kLimited;
    req.trade_order_info.market_id = kShangHai;
    strcpy(req.trade_order_info.security_id, "XXXXXX");
  
    stragegyMsgManager.SendMsg(kPktOrderReq, (char*)&req, sizeof(req));
}

void DemoMain() {
	StrategyMessageManager MessageManager;
	//����OnEvent�����ص���Ϣ
	MessageManager.SetOnEvent(3, StragegyOnEvent);
	//����OnMessage�����ص���Ϣ
	MessageManager.SetOnMessage(StragegyOnMessage);

    DoLoginReq(MessageManager);

    DoTradeOrderReq(MessageManager);

	//��ʼ��
	if(!MessageManager.Init("UTE_11_111_111", 11))
	{
		// LOG("ERROR")��
		exit(-1);
	}

	
    DoLoginReq(MessageManager);


	//Ӧ������ſɷ�������ί��
    DoTradeOrderReq(MessageManager);
	
	while(1)
	{
		sleep(1);
	}
}
}