#pragma once

void TestStrategyClient();