#pragma once

#include "que_comm.h"
#include "mauto.h"


namespace lb_common{

struct que_proc_info
{
	volatile int64 wrcmt;
	volatile int64 roundend;
	volatile int64 wrpos;
	int64 mask;
	int32 forward_check;
	uint32 userflag;
	int64 userpos[2];
	int64 filled;
	volatile int64 rdcmt;
	volatile int64 rdpos;
	char userdata[QUE_USER_DATA_LEN];
}CACHE_ALIGN;

class que_proc_buf
{
protected:
	char *pbuf;
	que_proc_info *que;
	int64 op_pid;
	
	int32 busy_readpos_check(que_proc_head &thead);
	void busy_read_check(que_proc_head &thead);
	void read_pop_cmt(int64 cmt_pos,int64 read_pos);
	
public:	
	
	FORCE_INLINE char *get_data(int64 pos)
	{
		return (pbuf + (pos&(que->mask)) + sizeof(que_proc_head));
	}

	
	int64 write_get(char *&o_data,int32 len);
	FORCE_INLINE void write_cmt(int64 getpos,int32 len)
	{
		que_proc_head *thead = (que_proc_head *)(pbuf +(getpos&(que->mask)));
		thead->pid = 0;
		thead->len = len;
		com_write_fence();
		thead->state = QUE_HEAD_STATE_WRITEOK;
		
		if(unlikely((getpos&(que->mask))==0))
			que->roundend = que->wrcmt;
		que->wrcmt = getpos+len+sizeof(que_proc_head);
	}
	int64 write(char *userdata,int32 len)
	{
		char *pd = NULL;
		int64 wr = write_get(pd,len);
		if(likely(wr != 0)){
			memcpy(pd,userdata,len);
			write_cmt(wr,len);
			return wr;
		}
		return 0;
	}
	
	int64 write_get_mth(char *&o_data,int32 len);
	FORCE_INLINE void write_cmt_mth(int64 getpos,int32 len)
	{
		que_proc_head *thead = (que_proc_head *)(pbuf +(getpos&(que->mask)));
		thead->state = QUE_HEAD_STATE_WRITEOK;
		
		register int64 d = getpos+len+sizeof(que_proc_head);
		do{
			register int64 t= que->wrcmt;
			if(likely(t < d)){
				if(likely(com_cas64(&(que->wrcmt),t,d) == t))
					break;
			}
			else{
				break;
			}
		}while(1);
	}
	inline int64 write_mth(char *userdata,int32 len){
		char *pd = NULL;
		int64 wr = write_get_mth(pd,len);
		if(likely(wr != 0)){
			memcpy(pd,userdata,len);
			write_cmt_mth(wr,len);
			return wr;
		}
		return 0;
	}
	
	
	//从上次读提交位置读,多进程写者需要监测读者是否存活
	int32 read_get(char *&o_data);
	FORCE_INLINE void read_cmt()
	{
		register int64 rd = (que->rdcmt);
		if(unlikely(rd == que->roundend)){
			rd += ((que->mask)+1 - (rd&(que->mask)));
		}
		
		que_proc_head *thead = (que_proc_head *)(pbuf + (rd&(que->mask)));
		thead->state = QUE_HEAD_STATE_IDLE;
		com_write_fence();
		(que->rdcmt) = rd + thead->len + sizeof(que_proc_head);
	}

	FORCE_INLINE int64 next_pos(int64 curpos,int32 read_len){
		return curpos + read_len + sizeof(que_proc_head);
	}
	//从读者自己维护的读位置读,多进程写者需要监测读者是否存活
	int32 read_get(char *&o_data,int64 &io_pos);
	FORCE_INLINE void read_cmt_pos(int64 dealpos)
	{
		if(dealpos > (que->rdcmt))
			(que->rdcmt) = dealpos;
	}
	inline int64 read_cmt_mth(int64 dealpos)
	{
		register int64 t;
		while(1){
			t = (que->rdcmt);
			if(unlikely(t > dealpos))
				return 0;
			if(com_cas64(&(que->rdcmt),t,dealpos)== t)
				return t;
		}
	}
	//返回： >0 读取长度，0空无数据；<0 buf_len 不够
	int32 read_pop(char *o_buf,int32 buf_len);

	
	FORCE_INLINE int64 get_used()
	{
		return ((que->wrcmt>que->wrpos?(que->wrcmt):(que->wrpos)) -(que->rdcmt));
	}
	FORCE_INLINE int64 get_free()
	{
		return ((que->mask)+1 -(que->wrcmt>que->wrpos?(que->wrcmt):(que->wrpos))+(que->rdcmt));
	}


	static int64 need_buf_size(int64 que_size);
	void init_shm(que_proc_info *pinfo,char *shm_addr,int64 que_size,
		int32 shm_isexist,int32 check_len=1024,uint32 user_flag=0);
	void start(int32 recove_type =0);
	

	FORCE_INLINE int64 get_write_pos(){return que->wrcmt;}
	FORCE_INLINE int64 get_read_pos(){return (que->rdcmt);}
	FORCE_INLINE int64 get_size(){return (que->mask)+1;}

	
	FORCE_INLINE uint32 get_user_flag(){return que->userflag;}
	FORCE_INLINE void set_user_flag(uint32 val){que->userflag=val;}
	FORCE_INLINE int64 *get_user_pos(){return que->userpos;}
	FORCE_INLINE char *get_user_data(){return que->userdata;}
	

	que_proc_buf()
	{
		pbuf = NULL;
		que = NULL;
		op_pid = 0;
	}
	~que_proc_buf(){}
};


}


