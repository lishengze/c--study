
#include "que_proc_buf.h"
#include "mutils.h"

namespace lb_common{


int64 que_proc_buf::write_get(char *&o_data,int32 len)
{
	len += sizeof(que_proc_head);
	
	register int64 tc = (que->wrcmt);
	if(unlikely(tc+len - (que->rdcmt) > (que->mask)))
		return 0;
	register int64 wr=(tc&(que->mask));
	if(likely(wr+len <= (que->mask)+1)){
		o_data = (pbuf + wr + sizeof(que_proc_head));
	}
	else{
		tc += ((que->mask)+1-wr);
		if(tc + len - (que->rdcmt) > (que->mask))
			return 0;
		//que->roundend = (que->wrcmt);
		o_data = (pbuf /*+ (tc&(que->mask))*/ + sizeof(que_proc_head));
	}
	return tc;
}
int64 que_proc_buf::write_get_mth(char *&o_data,int32 len)
{
	len += sizeof(que_proc_head);
	
	int64 ret=0;
	register int64 t;
	register int64 wr;
	
	do{
		wr = (que->wrpos);
		if(unlikely(wr+len - (que->rdcmt) > (que->mask)))
			return 0;
		
		t = (wr&(que->mask));
		if(likely(t+len <= (que->mask)+1)){
			t = wr+len;
			ret= wr;
		}
		else{
			ret = wr+((que->mask)+1-t);
			t = ret+len;
			if(t- (que->rdcmt) > (que->mask))
				return 0;
		}
		if(likely(com_cas64(&(que->wrpos),wr,t) == wr)){
			if(ret>wr || (wr&(que->mask))==0)
				que->roundend = wr;
			
			que_proc_head *thead = (que_proc_head *)(pbuf +(ret&(que->mask)));
			thead->pid = op_pid;
			thead->len = len - sizeof(que_proc_head);
			com_write_fence();
			thead->state = QUE_HEAD_STATE_WRITING;
			o_data = (pbuf + (ret&(que->mask)) + sizeof(que_proc_head));
			return ret;
		}
	}while(1);
}


int32 que_proc_buf::read_get(char *&o_data)
{
	int32 i = 0;
	int64 tre;
	int64 wr;
	que_proc_head *thead;

do{
	wr = (que->wrcmt);
	register int64 rd = (que->rdcmt);
	if(unlikely(rd >= wr))
		return 0;

	register int64 t = (rd&(que->mask));
	thead = (que_proc_head *)(pbuf + t);
	o_data = (pbuf + t + sizeof(que_proc_head));
	
	if(likely((wr&(que->mask)) != 0))
		t = (wr&(que->mask)) - t;
	else
		t = wr - rd;
	if(likely(t > 0))
	{
		if(likely(thead->state == QUE_HEAD_STATE_WRITEOK)){
			return thead->len;
		}
		else if(thead->state == QUE_HEAD_STATE_DISCARD){
			(que->rdcmt) += thead->len + sizeof(que_proc_head);
			continue;
		}
		
		i++;
		if(i == QUE_READ_CHECK_ROUND){
			i = 0;
			busy_read_check(*thead);
		}
		continue;
	}

	tre = que->roundend;
	if(unlikely(tre >= wr || tre<rd)){
		return 0;
	}
	
	t = tre - rd;
	if(likely(t > 0))
	{	
		if(likely(thead->state == QUE_HEAD_STATE_WRITEOK)){
			return thead->len;
		}
		else if(thead->state == QUE_HEAD_STATE_DISCARD){
			(que->rdcmt) += thead->len + sizeof(que_proc_head);
			continue;
		}
		
		i++;
		if(i == QUE_READ_CHECK_ROUND){
			i = 0;
			busy_read_check(*thead);
		}
		continue;
	}
	
	t= (rd&(que->mask));
	if(t != 0){
		rd += ((que->mask)+1 - t);
		thead = (que_proc_head *)(pbuf);// + (rd&(que->mask)));
		o_data = (pbuf /*+ (rd&(que->mask))*/ + sizeof(que_proc_head));
	}
	
	t = wr-rd;
	if(likely(t > 0))
	{	
		if(likely(thead->state == QUE_HEAD_STATE_WRITEOK)){
			(que->rdcmt) = rd;
			return thead->len;
		}
		else if(thead->state == QUE_HEAD_STATE_DISCARD){
			(que->rdcmt) = rd + thead->len + sizeof(que_proc_head);
			continue;
		}
		
		i++;
		if(i == QUE_READ_CHECK_ROUND){
			i = 0;
			busy_read_check(*thead);
		}
		continue;
	}
	else{
		return 0;
	}
	
}while(1);
	
	return 0;
}

void que_proc_buf::busy_read_check(que_proc_head &thead)
{
	if(thead.state == QUE_HEAD_STATE_WRITING){
		int32 tlen = thead.len;
		pthread_yield();
		if(thead.pid > 0){
			if(comm_utils::exist_pid(thead.pid)==0){
				thead.state = QUE_HEAD_STATE_DISCARD;
				com_write_fence();
				(que->rdcmt) += tlen + sizeof(que_proc_head);
			}
		}
	}
}

int32 que_proc_buf::read_get(char *&o_data,int64 &io_pos)
{
	int32 i = 0;
	int64 tre;
	int64 wr;
	que_proc_head *thead;
	
do{
	register int64 curpos = io_pos;
	wr = (que->wrcmt);
	if(unlikely(curpos >= wr))
		return 0;
	if(unlikely(curpos < (que->rdcmt))){
		curpos = (que->rdcmt);
		io_pos = curpos;
	}

	register int64 t = (curpos&(que->mask));
	thead = (que_proc_head *)(pbuf + t);
	o_data = (pbuf + t + sizeof(que_proc_head));
	
	if(likely((wr&(que->mask)) != 0))
		t = (wr&(que->mask)) - t;
	else
		t = wr - curpos;
	if(likely(t > 0)){
		if(likely(thead->state == QUE_HEAD_STATE_WRITEOK)){
			return thead->len;
		}
		else if(thead->state == QUE_HEAD_STATE_DISCARD){
			curpos += thead->len + sizeof(que_proc_head);
			io_pos = curpos;
			continue;
		}
		
		i++;
		if(i == QUE_READ_CHECK_ROUND){
			if((i = busy_readpos_check(*thead))!= 0){
				curpos += i + sizeof(que_proc_head);
				io_pos = curpos;
			}
			i = 0;
		}
		continue;
	}

	tre = que->roundend;
	if(unlikely(tre >= wr || tre<curpos)){
		return 0;
	}
	
	t = tre - curpos;
	if(likely(t > 0)){	
		if(likely(thead->state == QUE_HEAD_STATE_WRITEOK)){
			return thead->len;
		}
		else if(thead->state == QUE_HEAD_STATE_DISCARD){
			curpos += thead->len + sizeof(que_proc_head);
			io_pos = curpos;
			continue;
		}
		
		i++;
		if(i == QUE_READ_CHECK_ROUND){
			if((i = busy_readpos_check(*thead))!= 0){
				curpos += i + sizeof(que_proc_head);
				io_pos = curpos;
			}
			i = 0;
		}
		continue;
	}
	
	t= (curpos&(que->mask));
	if(t != 0){
		curpos += ((que->mask)+1 - t);
		thead = (que_proc_head *)(pbuf);// + (curpos&(que->mask)));
		o_data = (pbuf /*+ (curpos&(que->mask))*/ + sizeof(que_proc_head));
	}
	t = wr-curpos;
	if(likely(t > 0)){	
		if(likely(thead->state == QUE_HEAD_STATE_WRITEOK)){
			io_pos = curpos;
			return thead->len;
		}
		else if(thead->state == QUE_HEAD_STATE_DISCARD){
			curpos += thead->len + sizeof(que_proc_head);
			io_pos = curpos;
			continue;
		}
		
		i++;
		if(i == QUE_READ_CHECK_ROUND){
			if((i = busy_readpos_check(*thead))!= 0){
				curpos += i + sizeof(que_proc_head);
				io_pos = curpos;
			}
			i = 0;
		}
		continue;
	}
	else{
		return 0;
	}
}while(1);
	
}

int32 que_proc_buf::busy_readpos_check(que_proc_head &thead)
{
	if(thead.state == QUE_HEAD_STATE_WRITING){
		int32 tlen = thead.len;
		pthread_yield();
		if(thead.pid > 0){
			if(comm_utils::exist_pid(thead.pid)==0){
				thead.state = QUE_HEAD_STATE_DISCARD;
				return tlen;
			}
		}
	}
	return 0;
}

int32 que_proc_buf::read_pop(char *o_buf,int32 buf_len)
{
	int32 i = 0;
	int64 ts = 0;
	int64 tre;
	int64 wr;
	que_proc_head *thead;
	register int64 rd = (que->rdpos);


do{
	wr = (que->wrcmt);
	rd = (que->rdpos);
	if(unlikely(rd >= wr))
		return 0;

	register int64 t = (rd&(que->mask));
	thead = (que_proc_head *)(pbuf + t);
	
	if(likely((wr&(que->mask)) != 0))
		t = (wr&(que->mask)) - t;
	else
		t = wr - rd;
	if(likely(t > 0))
	{
		if(likely(thead->state == QUE_HEAD_STATE_WRITEOK)){
			if(unlikely(thead->len > buf_len))
				return -1;

			wr = rd + thead->len + sizeof(que_proc_head);
			if(likely(com_cas64(&(que->rdpos),rd,wr) == rd)){
				thead->pid = op_pid;
				com_write_fence();
				thead->state = QUE_HEAD_STATE_READING;
				ts = (ts==0?rd:ts);
				break;
			}
			else{
				continue;
			}
		}
		else if(thead->state == QUE_HEAD_STATE_DISCARD){
			wr = rd + thead->len + sizeof(que_proc_head);
			com_cas64(&(que->rdpos),rd,wr);
			ts = (ts==0?rd:ts);
			continue;
		}
		
		i++;
		if(i == QUE_READ_CHECK_ROUND){
			i = 0;
			busy_readpos_check(*thead);
		}
		continue;
	}

	tre = que->roundend;
	if(unlikely(tre >= wr || tre<rd)){
		return 0;
	}
	
	t = tre - rd;
	if(likely(t > 0))
	{	
		if(likely(thead->state == QUE_HEAD_STATE_WRITEOK)){
			if(unlikely(thead->len > buf_len))
				return -1;

			wr = rd + thead->len + sizeof(que_proc_head);
			if(likely(com_cas64(&(que->rdpos),rd,wr) == rd)){
				thead->pid = op_pid;
				com_write_fence();
				thead->state = QUE_HEAD_STATE_READING;
				ts = (ts==0?rd:ts);
				break;
			}
			else{
				continue;
			}
		}
		else if(thead->state == QUE_HEAD_STATE_DISCARD){
			wr = rd + thead->len + sizeof(que_proc_head);
			com_cas64(&(que->rdpos),rd,wr);
			ts = (ts==0?rd:ts);
			continue;
		}
		
		i++;
		if(i == QUE_READ_CHECK_ROUND){
			i = 0;
			busy_read_check(*thead);
		}
		continue;
	}

	tre = rd;
	t= (rd&(que->mask));
	if(t != 0){
		rd += ((que->mask)+1 - t);
		thead = (que_proc_head *)(pbuf);// + (rd&(que->mask)));
	}
	
	t = wr-rd;
	if(likely(t > 0))
	{	
		if(likely(thead->state == QUE_HEAD_STATE_WRITEOK)){
			if(unlikely(thead->len > buf_len))
				return -1;

			wr = rd + thead->len + sizeof(que_proc_head);
			if(likely(com_cas64(&(que->rdpos),tre,wr) == tre)){
				thead->pid = op_pid;
				com_write_fence();
				thead->state = QUE_HEAD_STATE_READING;
				ts = (ts==0?tre:ts);
				break;
			}
			else{
				continue;
			}
		}
		else if(thead->state == QUE_HEAD_STATE_DISCARD){
			wr = rd + thead->len + sizeof(que_proc_head);
			com_cas64(&(que->rdpos),tre,wr);
			ts = (ts==0?tre:ts);
			continue;
		}
		
		i++;
		if(i == QUE_READ_CHECK_ROUND){
			i = 0;
			busy_read_check(*thead);
		}
		continue;
	}
	else{
		return 0;
	}
}while(1);


	i = thead->len;
	memcpy(o_buf,((char *)thead)+sizeof(que_proc_head),i);
	thead->state = QUE_HEAD_STATE_IDLE;
	
	read_pop_cmt(wr,ts);
	return i;
}

void que_proc_buf::read_pop_cmt(int64 cmt_pos,int64 read_pos)
{
	que_proc_head *thead;
	register int64 rc = (que->rdcmt);
	if(read_pos == rc)
	{
		do{
			if(com_cas64(&(que->rdcmt),rc,cmt_pos) != rc)
				break;
			
			rc = (que->rdcmt);
			if(rc >= (que->rdpos))
				break;
		
			if(rc != que->roundend){
				read_pos = rc;
			}
			else{
				read_pos = rc + ((que->mask)+1 - (rc&(que->mask)));
			}
		
			thead = (que_proc_head *)(pbuf + (read_pos&(que->mask)));
			if(thead->state == QUE_HEAD_STATE_IDLE ||
				thead->state == QUE_HEAD_STATE_DISCARD)
			{
				cmt_pos = read_pos + thead->len + sizeof(que_proc_head);
				continue;
			}
			/*else if(thead->state == QUE_HEAD_STATE_READING)
			{
				break;
			}*/
			
			break;
		}while(1);
	}
	else if(cmt_pos - rc > que->forward_check)
	{
		while(rc < cmt_pos)
		{
			if(rc != que->roundend){
				read_pos = rc;
			}
			else{
				read_pos = rc + ((que->mask)+1 - (rc&(que->mask)));
			}
		
			thead = (que_proc_head *)(pbuf + (read_pos&(que->mask)));
			
			if(thead->state == QUE_HEAD_STATE_IDLE ||
				thead->state == QUE_HEAD_STATE_DISCARD)
			{
				int32 tlen = thead->len;
				if(com_cas64(&(que->rdcmt),rc,read_pos+tlen + sizeof(que_proc_head)) !=rc)
					break;
				rc = (que->rdcmt);
				continue;
			}
			else if(thead->state == QUE_HEAD_STATE_READING)
			{
				int32 tlen = thead->len;
				if(thead->pid == 0){
					break;
				}
				if(comm_utils::exist_pid(thead->pid)==0){
					thead->state = QUE_HEAD_STATE_DISCARD;
					com_cas64(&(que->rdcmt),rc,read_pos+tlen+ sizeof(que_proc_head));
					rc = (que->rdcmt);
					continue;
				}
			}
			
			break;
			
		}
	}
}

int64 que_proc_buf::need_buf_size(int64 que_size)
{
	int32 t = comm_utils::calc_power(que_size);
	return (1L<<t);
}

void que_proc_buf::init_shm(que_proc_info *pinfo,char *shm_addr,int64 que_size,
	int32 shm_isexist,int32 check_len,uint32 user_flag)
{	
	pbuf = shm_addr;
	que = pinfo;
	op_pid = comm_utils::get_pid();
	
	int64 tnum = need_buf_size(que_size);
	if(shm_isexist == 0 || (que->mask) != tnum){
		(que->wrpos) = CACHE_ALIGN_SIZE;
		(que->wrcmt) = CACHE_ALIGN_SIZE;
		que->roundend = 0;	
		(que->mask) = 0;
		que->forward_check = check_len;
		que->userflag = user_flag;
		que->userpos[0] = CACHE_ALIGN_SIZE;
		que->userpos[1] = CACHE_ALIGN_SIZE;
		(que->rdpos) = CACHE_ALIGN_SIZE;
		(que->rdcmt) = CACHE_ALIGN_SIZE;
		memset(que->userdata,0,QUE_USER_DATA_LEN);
		(que->mask) = tnum-1;
	}
	else{
		que->userflag = user_flag;
		que->forward_check = check_len;
	}
	
}

void que_proc_buf::start(int32 recove_type)
{
	if((que->rdcmt) < CACHE_ALIGN_SIZE)
		(que->rdcmt) = CACHE_ALIGN_SIZE;
	if((que->wrcmt) < CACHE_ALIGN_SIZE)
		(que->wrcmt) = CACHE_ALIGN_SIZE;
	(que->wrpos) = (que->wrcmt);
	if(que->roundend > (que->wrcmt))
		que->roundend = (que->wrcmt);
	if((que->rdcmt) >= (que->wrcmt)){
		(que->rdcmt) = (que->wrcmt);
	}
	(que->rdpos) = (que->rdcmt);

	if(recove_type == QUE_RECOVE_TYPE_RESTART){
		(que->wrpos) = CACHE_ALIGN_SIZE;
		(que->wrcmt) = CACHE_ALIGN_SIZE;
		que->roundend = 0;
		(que->rdpos) = CACHE_ALIGN_SIZE;
		(que->rdcmt) = CACHE_ALIGN_SIZE;
	}
	else if(recove_type == QUE_RECOVE_TYPE_CONTINUE){
		(que->wrpos) = (que->wrcmt);
		(que->rdcmt) = (que->wrcmt);
		(que->rdpos) = (que->rdcmt);
	}
	else{
		int64 tr;
		int64 t = (que->rdcmt);
		int64 te = (que->wrcmt)>(que->wrpos)?(que->wrcmt):(que->wrpos);
		que_proc_head *thead;
		
		while(t<te)
		{
			if(t != que->roundend){
				tr = t;
			}
			else{
				tr = t + ((que->mask)+1 - (t&(que->mask)));
			}
			if(t < que->rdcmt){
				t = que->rdcmt;
				continue;
			}
			
			thead = (que_proc_head *)(pbuf+(tr&(que->mask)));
			if(thead->state == QUE_HEAD_STATE_WRITING ||
				thead->state == QUE_HEAD_STATE_READING)
			{
				int32 tlen = thead->len;
				if(thead->pid > 0){
					if(comm_utils::exist_pid(thead->pid)==0){
						thead->state = QUE_HEAD_STATE_DISCARD;
					}
				}
			}

			if(thead->state == QUE_HEAD_STATE_IDLE){
				if(t == (que->rdcmt)){
					com_cas64(&(que->rdcmt),t,tr+thead->len+ sizeof(que_proc_head));
					t= que->rdcmt;
					continue;
				}
			}
			else if(thead->state == QUE_HEAD_STATE_DISCARD){
				if(t == (que->rdcmt)){
					com_cas64(&(que->rdcmt),t,tr+thead->len+ sizeof(que_proc_head));
					t= que->rdcmt;
					continue;
				}
				if(t >= (que->wrcmt)){
					com_cas64(&(que->wrcmt),t,tr+thead->len+ sizeof(que_proc_head));
				}
			}
			else if(thead->state == QUE_HEAD_STATE_WRITEOK){
				if(t >= (que->wrcmt)){
					com_cas64(&(que->wrcmt),t,tr+thead->len+ sizeof(que_proc_head));
				}
			}

			t = tr+thead->len+sizeof(que_proc_head);
		}
	}
	return;
}


}

