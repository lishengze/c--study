
#include "mutils.h"
//#include <iconv.h>

namespace lb_common{

uint64 comm_utils::get_rdtsc()
{
#ifdef __i386__
	uint64 t;
	__asm__ volatile("rdtsc" : "=A"(t));
	return t;
#elif defined(__x86_64__) || defined(__amd64__)
	uint64 a,d;
	__asm__ volatile("rdtsc" : "=a"(a), "=d"(d));
	return (d<<32)|a;
#else //ARM CPU
	uint32 cc = 0;
	__asm__ volatile("mrc p15, 0, %0, c9, c13, 0":"=r"(cc));
	return (uint64)cc;
#endif
}

uint64 comm_utils::get_tick()
{
	uint64 ret;
	struct timespec tms = {0,0};
    clock_gettime(CLOCK_MONOTONIC,&tms);
	ret = (uint64)(tms.tv_sec*1000000000+tms.tv_nsec);
	return ret;
}

void comm_utils::sleep_s(int32 sec)
{
	sleep(sec);
}

void comm_utils::sleep_ms(int32 millisec)
{
	struct timespec req;
	req.tv_sec = millisec/1000;
	req.tv_nsec = (millisec -req.tv_sec*1000)*1000000;
	nanosleep(&req,NULL);
}
void comm_utils::sleep_us(int32 us)
{
	struct timespec req;
	req.tv_sec = us/1000000;
	req.tv_nsec = (us -req.tv_sec*1000000)*1000;
	nanosleep(&req,NULL);
}

int32 comm_utils::get_time()
{
	struct tm tmloc;
	time_t curtime = time(0);		
	localtime_r(&curtime,&tmloc);

	return (tmloc.tm_hour*10000 + tmloc.tm_min*100 + tmloc.tm_sec);
}

void comm_utils::get_time(char *o_buf,int32 buf_len)
{
	assert(buf_len >= 9);
	struct tm tmloc;
	time_t curtime = time(0);		
	localtime_r(&curtime,&tmloc);
	
	snprintf(o_buf,buf_len,"%02d:%02d:%02d",tmloc.tm_hour,tmloc.tm_min,tmloc.tm_sec);
	o_buf[8] = '\0';
}

int32 comm_utils::get_date()
{
	struct tm p;
	time_t curtime = time(0);		
	localtime_r(&curtime,&p);

	return ((1900+p.tm_year)*10000+(1+p.tm_mon)*100+p.tm_mday);
}


void *comm_utils::aligned_malloc(size_t size,size_t alignment)
{
	void *p =NULL;
	posix_memalign(&p,alignment,size);
	return p;
}
void comm_utils::aligned_free(void *p)
{
	free(p);
}

//返回：1-共享内存存在并打开，0-新建打开；<0-失败
int32 comm_utils::map_shm(void *&o_addr,const char *shm_name,int64 shm_size,int32 hugepage)
{
	int32 shmisexist = 0;
	int32 shmfd = shm_open(shm_name,O_RDWR,S_IRWXU|S_IRGRP|S_IWGRP);
	if(shmfd < 0){
		if(errno != ENOENT)
			return -1;
		
		shmfd = shm_open(shm_name,O_RDWR|O_CREAT|O_EXCL,S_IRWXU|S_IRGRP|S_IWGRP);
		if(shmfd < 0){
			assert(errno != EEXIST);
			return -2;
		}
		shmisexist = 0;
	}
	else{
		shmisexist = 1;
	}

	if(ftruncate(shmfd,shm_size) < 0){
		close(shmfd);
		return -3;
	}

	void *pshm_addr = NULL;
	if(hugepage == 1){
		pshm_addr = mmap(NULL,shm_size,PROT_READ|PROT_WRITE,MAP_HUGETLB|MAP_SHARED,
			shmfd,0);
	}
	else{
		pshm_addr = mmap(NULL,shm_size,PROT_READ|PROT_WRITE,MAP_SHARED,
			shmfd,0);
	}
	if(pshm_addr == MAP_FAILED){
		return -4;
	}
	mlock(pshm_addr,shm_size);
	o_addr = pshm_addr;

	close(shmfd);
	return shmisexist;
}
void comm_utils::close_shm(void *shm_addr,const char *shm_name,int64 shm_size)
{
	if(NULL != shm_addr)
		munmap(shm_addr, shm_size);
	if(NULL != shm_name &&shm_name[0] != '\0')
		shm_unlink(shm_name);
}


int32 comm_utils::write_file(FILE *tfp,char *data,int32 len)
{
	register int nleft = len;
	register int nwritten = 0;
	char  *ptr = data;

	while(nleft > 0)
	{
	     if((nwritten = fwrite(ptr, sizeof(char),nleft,tfp))< 0) {
	         if (errno ==EINTR || errno ==EAGAIN){
	             continue;
	         }
	         else if(nleft == len){
	             return -1;
	         }else{
	             return -2;
	         }
	     }else if(nwritten == 0) {
	         continue;
	     }
	     nleft -= nwritten;
	     ptr += nwritten;
	}
	//fflush(tfp);
	return len;
}

int32 comm_utils::read_file(FILE *tfp, char *buf, int len)
{
	int32 nleft = len;
	int32 readlen = 0;
	int32 ret = 0;
	//GetSysLastError() = 0;
    while (nleft > 0) {
        if ((ret = fread(buf+readlen,sizeof(char), nleft,tfp)) <= 0)
        {
            if (errno ==EINTR || errno ==EAGAIN) {
                continue;
            }
			else if(feof(tfp)){
				return readlen;
			}
            else {
                return ret;
            }
        }
        nleft -= ret;
        readlen += ret;
    }
    return readlen;
}

int32 comm_utils::exist_file(const char *file_name)
{
	if(access(file_name,F_OK) == 0)
		return 1;
	return 0;
}
int32 comm_utils::exist_path(const char *path_name)
{
	struct stat attr;
    int32 ret = stat(path_name,&attr);
	if(ret == 0){
		//验证是否为目录
    	return S_ISDIR(attr.st_mode)?1:0;
	}
    else if(errno == ENOENT){
		return 0;
    }
	else{
        //其他错误,如权限问题
        return -1;
    }
}
int32 comm_utils::make_path(const char *path_name)
{
	if(exist_path(path_name) == 0){
		return mkdir(path_name,0775);
	}
	return 0;
}


int32 comm_utils::exist_pid(int64 proc_id)
{
	char pid_file[256];
	memset(pid_file,0,sizeof(pid_file));
	snprintf(pid_file,255,"%s%ld","/proc/",proc_id);
	
	return exist_path(pid_file);
}
int64 comm_utils::get_pid()
{
	return (int64)(getpid());
}

int32 comm_utils::calc_power(int64 n)
{
	if(unlikely(n<1))
		return 0;
	
	int64 ts = n;
	int32 tn = 0;
	while(ts != 1){
		tn++;	
		ts = (ts>>1);
	}
	if((1UL<<tn) < n)
		tn++;
	return tn;
}
/*
int32 comm_utils::utf8_to_gb(const char *gb_name,char *dst,char *src,
	int32 dstsize,int32 srcsize)
{
	iconv_t tcd;
	if((tcd = iconv_open(gb_name,"utf-8")) ==0)
		return -1;
	
	memset(dst,0,dstsize);
	char **tsource = &src;
	char **tdest = &dst;
	size_t tsn = srcsize;
	size_t tdn = dstsize;
	iconv(tcd,tsource,&tsn,tdest,&tdn);
	iconv_close(tcd);
	return 0;
}
int32 comm_utils::gb_to_utf8(const char *gb_name,char *dst,char *src,
	int32 dstsize,int32 srcsize)
{
	iconv_t tcd;
	if((tcd = iconv_open("utf-8",gb_name)) ==0)
		return -1;
	
	memset(dst,0,dstsize);
	char **tsource = &src;
	char **tdest = &dst;
	size_t tsn = srcsize;
	size_t tdn = dstsize;
	iconv(tcd,tsource,&tsn,tdest,&tdn);
	iconv_close(tcd);
	return 0;
}
*/

}


