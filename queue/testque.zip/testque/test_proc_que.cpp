
#include "que_proc_buf.h"
//#include "que_mth_buf.h"
#include "comm_sys.h"
#include "mutils.h"

using namespace lb_common;


int64 g_read_th_arg[10];
char g_write_th_arg[10];

int32 g_wr_th_num = 0;
int32 g_rd_th_num = 0;
int32 g_stop_th_flag = 0;
int32 g_wr_que_len= 0;

que_proc_buf g_test_que;
//que_mth_buf g_test_que;

void *write_thread_func(void *arg)
{
	int32 tus = g_wr_th_num/2;
	if(tus == 0){
		tus = 1;
	}
	if(g_rd_th_num == 1)
		tus++;
	
	while(g_stop_th_flag == 0);
	
	char tc = *((char *)arg);
	char *tv = new char[g_wr_que_len];
	for(int32 i=0;i<g_wr_que_len;i++){
		tv[i] = tc;
	}
	tv[g_wr_que_len-1] = '\0';
	
	printf("write thread start,c=%c\n",tc);
	
	int64 count = 0;
	int32 i= 0;
	char *pbuf;
	int64 tpos;
	do{
		i = 0;
		if(g_wr_th_num == 1){
			do{
				tpos = g_test_que.write_get(pbuf,g_wr_que_len);
				if(tpos > 0)
					break;
				
				if((i/30000000) == 0){
				//	printf("write queue have fulled,count=%ld,c=%c\n",count,tc);
					i = 0;
				}
				i++;
			}while(g_stop_th_flag == 1);
	
			if(tpos >0){
			//memcpy(pbuf,tv,g_wr_que_len);
			g_test_que.write_cmt(tpos,g_wr_que_len);
			count++;
			}
		}
		else{
			
			do{
				tpos = g_test_que.write_get_mth(pbuf,g_wr_que_len);
				if(tpos > 0)
					break;
				
				if((i/30000000) == 0){
				//	printf("write queue have fulled,count=%ld,c=%c\n",count,tc);
					i = 0;
				}
				i++;
			}while(g_stop_th_flag == 1);
			
			if(tpos >0){
			//memcpy(pbuf,tv,g_wr_que_len);
			g_test_que.write_cmt_mth(tpos,g_wr_que_len);
			count++;
			}
		}
		
		//comm_utils::sleep_us(tus);
		
	}while(g_stop_th_flag == 1);
	
	printf("write thread end,count=%ld,c=%c\n",count,tc);
	
	return NULL;
}

void *read_thread_func(void *arg)
{
	int32 tus = g_rd_th_num/2;
	if(tus == 0)
		tus = 1;
	
	while(g_stop_th_flag == 0);
	
	printf("read thread start\n");
	
	char tcache[4096];
	char tc;
	int64 count = 0;
	//int32 i= 0;
	int32 len = 0;
	char *pbuf;
	
	do{
		//i = 0;
		if(g_rd_th_num == 1){
			while((len = g_test_que.read_get(pbuf)) > 0){
				assert(len == g_wr_que_len);
			/*	tc = pbuf[0];
				for(int32 j=1;j<len-2;j++){
					assert(tc == pbuf[j]);
				}
			*/
				 g_test_que.read_cmt();
				count++;
			}
		}
		else{
			
			while((len = g_test_que.read_pop(tcache,sizeof(tcache))) > 0){
				assert(len == g_wr_que_len);
			/*	tc = tcache[0];
				for(int32 j=1;j<len-2;j++){
					assert(tc == tcache[j]);
				}
			*/
				count++;
			}
		}
		
		//comm_utils::sleep_us(tus);
		
	}while(g_stop_th_flag == 1 || g_test_que.get_used()>0);
	
	printf("read thread end,count=%ld\n",count);
	
	return NULL;
}

void *readpos_thread_func(void *arg)
{
	int32 tus = g_rd_th_num/2;
	if(tus == 0)
		tus = 1;
	
	while(g_stop_th_flag == 0);
	
	int64 &tpos = *((int64 *)arg);
	char tc;
	int64 count = 0;
	//int32 i= 0;
	int32 len = 0;
	char *pbuf;
	tpos = g_test_que.get_read_pos();
	
	printf("read pos thread start,read_pos=%ld\n",tpos);
	
	do{
		//i = 0;
			while((len = g_test_que.read_get(pbuf,tpos)) > 0){
				assert(len == g_wr_que_len);
				/*tc = pbuf[0];
				for(int32 j=1;j<len-2;j++){
					assert(tc == pbuf[j]);
				}
				*/
				tpos = g_test_que.next_pos(tpos,len);
				if(g_rd_th_num == 1)
					g_test_que.read_cmt_pos(tpos);
				
				count++;
			}
		
		
		//comm_utils::sleep_us(tus);
		
	}while(g_stop_th_flag == 1 || g_test_que.get_used()>0);
	
	printf("read pos thread end,count=%ld,read_pos=%ld\n",count,tpos);
	
	return NULL;
}

void *cmt_read_thread_func(void *arg)
{
	int32 tus = g_rd_th_num/2;
	if(tus == 0)
		tus = 1;
	if(g_rd_th_num == 1)
		return NULL;
	
	while(g_stop_th_flag == 0);
	
	printf("commit pos thread start\n");
	
	int32 i= 0;
	int64 tpos = 0;
	
	do{
		tpos = g_read_th_arg[0];
		for(i=1;i<g_rd_th_num;i++){
			int64 t= g_read_th_arg[i];
			if(tpos > t){
				tpos = t;
			}
		}
		//g_test_que.read_cmt_mth(tpos);
		g_test_que.read_cmt_pos(tpos);
		//comm_utils::sleep_us(tus);
		
	}while(g_stop_th_flag == 1 || g_test_que.get_used()>0);
	
	printf("commit pos thread end,commit_pos=%ld\n",tpos);
	
	return NULL;
}

int main(int argc,char *argv[])
{
	if(argc < 4){
		printf("exe que_size_MB write_thread_num read_thread_num write_len read_type\n");
		return -1;
	}
	int32 read_type= 0;
	int64 que_size = atoi(argv[1]);
	que_size = (que_size<<20);
	g_wr_th_num = atoi(argv[2]);
	g_rd_th_num = atoi(argv[3]);
	if(argc > 4){
		g_wr_que_len = atoi(argv[4]);
	}
	else{
		g_wr_que_len = 120;
	}
	if(argc > 5){
		read_type = atoi(argv[5]);
	}
	else{
		read_type = 0;
	}
	
	printf("que_size=%lx, write_thread_num=%d, write_len=%d\n",que_size,g_wr_th_num,g_wr_que_len);
	printf("read_thread_num=%d, read_type=%d, cache_line=%d\n",g_rd_th_num,read_type,CACHE_ALIGN_SIZE);
	
	for(int8 i=0;i<10;i++){
		g_write_th_arg[i] = '0' + i;
		g_read_th_arg[i] = 64;
	}
	
	int64 ts = que_proc_buf::need_buf_size(que_size);
	ts += sizeof(que_proc_info);
	
	void *tp = NULL;
	int32 ret = comm_utils::map_shm(tp,"test_proc_que",ts,0);
	printf("mmap que,ret=%d\n",ret);
	if(ret < 0){
		return ret;
	}
	
	que_proc_info *tqinfo = (que_proc_info *)tp;
	g_test_que.init_shm(tqinfo,((char *)tp) + sizeof(que_proc_info),que_size,ret,1024,0);
	g_test_que.start(QUE_RECOVE_TYPE_RESTART);
	
	
	g_stop_th_flag = 0;
	ret = 0;
	for(int32 i=0;i<g_rd_th_num;i++)
	{
		pthread_t thid;
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		void *tparg = reinterpret_cast<void *>(&(g_read_th_arg[i]));
		if(read_type == 0){
			if(::pthread_create(&thid,&attr,read_thread_func,tparg) !=0){
				g_stop_th_flag = 2;
				ret = -1;
			}
		}
		else{
			if(::pthread_create(&thid,&attr,readpos_thread_func,tparg) !=0){
				g_stop_th_flag = 2;
				ret = -1;
			}
		}
	}
	if(read_type != 0 && ret == 0){
		pthread_t thid;
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		if(::pthread_create(&thid,&attr,cmt_read_thread_func,NULL) !=0){
			g_stop_th_flag = 2;
			ret = -1;
		}
	}
	if(ret == 0){
		for(int32 i=0;i<g_wr_th_num;i++){
			pthread_t thid;
			pthread_attr_t attr;
			pthread_attr_init(&attr);
			void *tparg = reinterpret_cast<void *>(&(g_write_th_arg[i]));
			
				if(::pthread_create(&thid,&attr,write_thread_func,tparg) !=0){
					g_stop_th_flag = 2;
					ret = -1;
				}
			
		}
	}
	
	printf("create thread,ret=%d\n",ret);
	
	if(ret == 0){
		g_stop_th_flag = 1;
		sleep(10);
	}
	
	g_stop_th_flag = 2;
	sleep(10);
	
	printf("thread end,que_wrcmt=%ld,que_rdcmt=%ld,que_uesd=%ld\n",
		g_test_que.get_write_pos(),
		g_test_que.get_read_pos(),
		g_test_que.get_used());
	
	return 0;
}

