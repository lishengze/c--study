#pragma once

#include "comm_sys.h"

/*
#include <string>
#include <cstring>
#include <vector>

using namespace std::vector;
using namespace std::string;
*/


namespace lb_common{

class comm_utils
{
public:

	static uint64 get_rdtsc();
	static uint64 get_tick();
	static void sleep_s(int32 sec);
	static void sleep_ms(int32 millisec);
	static void sleep_us(int32 us);
	static int32 get_time();
	static void get_time(char *o_buf,int32 buf_len);
	static int32 get_date();

	
	static void *aligned_malloc(size_t size,size_t alignment);
	static void aligned_free(void *p);
	//返回：1-共享内存存在并打开，0-新建打开；<0-失败
	static int32 map_shm(void *&o_addr,const char *shm_name,int64 shm_size,int32 hugepage=1);
	static void close_shm(void *shm_addr,const char *shm_name,int64 shm_size);

	
	static int32 write_file(FILE *tfp,char *data,int32 len);
	static int32 read_file(FILE *tfp, char *buf, int len);
	//返回：1-存在；0-不存在；<0，出错
	static int32 exist_file(const char *file_name);
	static int32 make_path(const char *path_name);
	//返回：1-存在；0-不存在；<0，出错
	static int32 exist_path(const char *path_name);
	
	//返回：1-存在；0-不存在；<0，出错
	static int32 exist_pid(int64 proc_id);
	static int64 get_pid();

	static int32 calc_power(int64 n);
/*
	static int32 utf8_to_gb(const char *gb_name,char *dst,char *src,
		int32 dstsize,int32 srcsize);
	static int32 gb_to_utf8(const char *gb_name,char *dst,char *src,
		int32 dstsize,int32 srcsize);
*/
};

}

